<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="tile-map" tilewidth="32" tileheight="32" tilecount="483" columns="23">
 <image source="iu.png" width="736" height="672"/>
</tileset>
